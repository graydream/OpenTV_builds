<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../aboutdialog/aboutdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../aboutdialog/aboutdialog.ui" line="30"/>
        <source>About</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../aboutdialog/aboutdialog.ui" line="42"/>
        <source>Logo</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../aboutdialog/aboutdialog.ui" line="58"/>
        <source>License</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../aboutdialog/aboutdialog.ui" line="73"/>
        <source>Acknowledgement</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow/mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow/mainwindow_menu.cpp" line="10"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../mainwindow/mainwindow_menu.cpp" line="17"/>
        <source>AAAA</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PrefDialog</name>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="30"/>
        <source>Settings</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="52"/>
        <source>Language</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="58"/>
        <source>Audio</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="80"/>
        <source>Sample Rate:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="93"/>
        <source>Channels</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="109"/>
        <source>Video</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="121"/>
        <source>Resolution:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="135"/>
        <source>4K</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="140"/>
        <source>2K</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="145"/>
        <source>1080p</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="150"/>
        <source>720p</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="155"/>
        <source>420p</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../prefdialog/prefdialog.ui" line="160"/>
        <source>320p</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>ProgramList</name>
    <message>
        <source>Favorite Programs</source>
        <translation type="vanished">收藏</translation>
    </message>
    <message>
        <source>Programs</source>
        <translation type="vanished">节目列表</translation>
    </message>
    <message>
        <location filename="../programlist/programlist.cpp" line="201"/>
        <source>Favorite</source>
        <translation>收藏</translation>
    </message>
    <message>
        <location filename="../programlist/programlist.cpp" line="215"/>
        <source>IPTV</source>
        <translation>IP电视节目</translation>
    </message>
    <message>
        <location filename="../programlist/programlist.cpp" line="227"/>
        <source>DVB TV</source>
        <translation>数字电视节目</translation>
    </message>
    <message>
        <location filename="../programlist/programlist.cpp" line="237"/>
        <source>Analog TV</source>
        <translation>模拟电视节目</translation>
    </message>
</context>
</TS>
